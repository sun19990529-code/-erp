# ============================================================
# Mingsheng ERP-MES Deploy Script (Dev Machine -> Server)
# Usage: .\deploy\deploy.ps1
# Requires: OpenSSH on server (run server-init.ps1 first)
# ============================================================

# ==================== Config ====================
$SERVER_USER = "sunqiming"
$SERVER_HOST = "suncraft.site"
$SERVER_PORT = 22
$REMOTE_PATH = "D:\erp-mes-system"
$LOCAL_PATH  = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)
# =================================================

$ErrorActionPreference = "Stop"

Write-Host ""
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "  ERP-MES Deploy Tool v1.1 (Win->Win)" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "  Local:  $LOCAL_PATH" -ForegroundColor Gray
Write-Host "  Remote: ${SERVER_USER}@${SERVER_HOST}:${REMOTE_PATH}" -ForegroundColor Yellow
Write-Host ""

$confirm = Read-Host "Deploy to ${SERVER_HOST}? (y/N)"
if ($confirm -ne 'y' -and $confirm -ne 'Y') {
    Write-Host "Cancelled." -ForegroundColor Yellow
    exit 0
}

# ==================== Step 1: Build Frontend ====================
Write-Host ""
Write-Host "[1/5] Building frontend..." -ForegroundColor Yellow
Push-Location "$LOCAL_PATH\frontend"
npm run build
if ($LASTEXITCODE -ne 0) {
    Write-Host "[FAIL] Frontend build failed!" -ForegroundColor Red
    Pop-Location
    Read-Host "Press Enter to exit"
    exit 1
}
Pop-Location
Write-Host "[OK] Frontend build done" -ForegroundColor Green

# ==================== Step 2: Package ====================
Write-Host ""
Write-Host "[2/5] Packaging..." -ForegroundColor Yellow

$tempArchive = "$env:TEMP\erp-deploy-$(Get-Date -Format 'yyyyMMdd-HHmmss').tar.gz"

Push-Location (Split-Path $LOCAL_PATH -Parent)
$folderName = Split-Path $LOCAL_PATH -Leaf

tar -czf $tempArchive `
    --exclude="$folderName/node_modules" `
    --exclude="$folderName/backend/node_modules" `
    --exclude="$folderName/frontend/node_modules" `
    --exclude="$folderName/*.db" `
    --exclude="$folderName/backend/*.db" `
    --exclude="$folderName/backend/*.db-journal" `
    --exclude="$folderName/.git" `
    --exclude="$folderName/backups" `
    --exclude="$folderName/frontend/dist" `
    $folderName

Pop-Location

if (-not (Test-Path $tempArchive)) {
    Write-Host "[FAIL] Package failed!" -ForegroundColor Red
    Read-Host "Press Enter to exit"
    exit 1
}

$archiveSizeMB = [math]::Round((Get-Item $tempArchive).Length / 1MB, 2)
Write-Host "[OK] Package done: $archiveSizeMB MB" -ForegroundColor Green

# ==================== Step 3: Upload ====================
Write-Host ""
Write-Host "[3/5] Uploading to server..." -ForegroundColor Yellow

$remoteTempFile = "C:\TEMP\erp-deploy.tar.gz"
ssh -p $SERVER_PORT "${SERVER_USER}@${SERVER_HOST}" "if not exist C:\TEMP mkdir C:\TEMP"
scp -P $SERVER_PORT $tempArchive "${SERVER_USER}@${SERVER_HOST}:${remoteTempFile}"

if ($LASTEXITCODE -ne 0) {
    Write-Host "[FAIL] Upload failed! Check SSH connection." -ForegroundColor Red
    Remove-Item $tempArchive -ErrorAction SilentlyContinue
    Read-Host "Press Enter to exit"
    exit 1
}
Write-Host "[OK] Upload done" -ForegroundColor Green

# ==================== Step 4: Extract on Server ====================
Write-Host ""
Write-Host "[4/5] Extracting on server..." -ForegroundColor Yellow

$remoteParent = Split-Path $REMOTE_PATH -Parent

ssh -p $SERVER_PORT "${SERVER_USER}@${SERVER_HOST}" @"
    cd /d $remoteParent && tar -xzf $remoteTempFile --strip-components=0 -C . && del $remoteTempFile && echo EXTRACT_OK
"@

if ($LASTEXITCODE -ne 0) {
    Write-Host "[FAIL] Extract failed!" -ForegroundColor Red
    Remove-Item $tempArchive -ErrorAction SilentlyContinue
    Read-Host "Press Enter to exit"
    exit 1
}
Write-Host "[OK] Extract done" -ForegroundColor Green

# ==================== Step 5: Install deps + Restart ====================
Write-Host ""
Write-Host "[5/5] Installing deps and restarting..." -ForegroundColor Yellow

ssh -p $SERVER_PORT "${SERVER_USER}@${SERVER_HOST}" @"
    cd /d $REMOTE_PATH\backend && npm install --production && echo DEPS_OK
"@

ssh -p $SERVER_PORT "${SERVER_USER}@${SERVER_HOST}" @"
    cd /d $REMOTE_PATH\backend && pm2 restart erp 2>nul || pm2 start server.js --name erp 2>nul || echo [NOTE] PM2 not found, please restart manually
"@

# ==================== Cleanup ====================
Remove-Item $tempArchive -ErrorAction SilentlyContinue

Write-Host ""
Write-Host "========================================" -ForegroundColor Green
Write-Host "  DEPLOY SUCCESS!" -ForegroundColor Green
Write-Host "  https://$SERVER_HOST" -ForegroundColor Green
Write-Host "========================================" -ForegroundColor Green
Write-Host ""
Read-Host "Press Enter to exit"
